'''a=input("enter your fast name:")
b=input("enter your last name:")
print("Hello,",a,b,"!","welcome to the python program.")
'''
import random
num=random.randint(1,10)
a=int(input("how many attempts you want :"))
n=a
print("the secret number is in between 1 to 10")
while n>=1:
    print(f"you have {n} number of guess")
    guess=int(input("enter the your guess : "))
    n=n-1
    if guess==num:
        print("congrats")
        break
    else :
            if guess<num:
                print("your guess is wrong . Try higher")
            else :
                print("your guess is wrong . Try lower")
    if guess!=num and n==0:
        print("too many wrong attempts")
print(f"the secret number is : {num}")
        