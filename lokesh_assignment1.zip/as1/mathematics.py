num1=float(input("enter your first number: "))
num2=float(input("enter your second number: "))
a=num1+num2
s=num1-num2
m=num1*num2
d=num1/num2
print("addition:",a,"\nsubraction:",s,"\nmultipilcation:",m,"\ndivision:",d)

